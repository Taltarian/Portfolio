#ifndef UPDATE_H
#define UPDATE_H
void update(short array[], short dummy_array[], long int args[]);
void printStatus(short array[], long int length);
void iterateUpdate(short array[], short dummy_array[], long int args[]);


#endif
