#ifndef ARGCHECK_H
#define ARGCHECK_H
void argCheck(int nargs, long int args[]);

void convertCheckArgs(char *argv[], long int args[], int nargs);

#endif

