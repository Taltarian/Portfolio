#ifndef FILLARRAY_H
#define FILLARRAY_H
void fillArray(long int length, short array[]);
void copyArray(short original[], short destination[], long int length);

#endif
